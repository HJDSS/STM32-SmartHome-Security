..\output\ffsystem.o: ..\Middlewares\FatFs\ffsystem.c
..\output\ffsystem.o: ..\Middlewares\FatFs\ff.h
..\output\ffsystem.o: ..\Middlewares\FatFs\ffconf.h
..\output\ffsystem.o: D:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
