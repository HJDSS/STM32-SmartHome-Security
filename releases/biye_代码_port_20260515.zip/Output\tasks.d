..\output\tasks.o: ..\Middlewares\FreeRTOSV9\Source\tasks.c
..\output\tasks.o: D:\Keil_v5\ARM\ARMCC\Bin\..\include\stdlib.h
..\output\tasks.o: D:\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
