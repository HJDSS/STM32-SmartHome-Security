..\output\ff.o: ..\Middlewares\FatFs\ff.c
..\output\ff.o: D:\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
..\output\ff.o: ..\Middlewares\FatFs\ff.h
..\output\ff.o: ..\Middlewares\FatFs\ffconf.h
..\output\ff.o: D:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
..\output\ff.o: ..\Middlewares\FatFs\diskio.h
