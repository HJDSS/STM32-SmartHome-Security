..\output\list.o: ..\Middlewares\FreeRTOSV9\Source\list.c
..\output\list.o: D:\Keil_v5\ARM\ARMCC\Bin\..\include\stdlib.h
