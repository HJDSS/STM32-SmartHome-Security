..\output\heap_4.o: ..\Middlewares\FreeRTOSV9\Source\portable\MemMang\heap_4.c
..\output\heap_4.o: D:\Keil_v5\ARM\ARMCC\Bin\..\include\stdlib.h
