..\output\event_groups.o: ..\Middlewares\FreeRTOSV9\Source\event_groups.c
..\output\event_groups.o: D:\Keil_v5\ARM\ARMCC\Bin\..\include\stdlib.h
