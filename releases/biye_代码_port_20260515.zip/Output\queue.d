..\output\queue.o: ..\Middlewares\FreeRTOSV9\Source\queue.c
..\output\queue.o: D:\Keil_v5\ARM\ARMCC\Bin\..\include\stdlib.h
..\output\queue.o: D:\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
