﻿#include <stdio.h>
#include <string.h>
#include "board_config.h"
#include "delay.h"
#include "gpio.h"
#include "timer.h"
#include "key4_4.h"
#include "dht11.h"
#include "mq2.h"
#include "hc_sr501.h"
#include "usart1.h"
#include "usart2.h"
#include "ov7670_fifo.h"
#include "capture_task.h"
#include "Capture.h"
#include "keyboard_sm.h"
#include "lock_manager.h"
#include "oled_view.h"
#include "oled.h"         /* [M1.9] 插桩需要 OLED_ShowChar 直接写格 */
#include "linkage.h"
#include "esp8266_tls.h"
#include "syslog.h"
#include "app_types.h"
#include "app_params.h"
#include "log.h"
#include "app_rtos.h"
#include "wdg.h"

#define BUF2_MAX 800
#define BUF3_MAX 400

volatile u8 RELAY_TIME = 0;
volatile u8 InitDisplay = 1;
volatile u8 pass = 0;
volatile u8 ReInputEn = 0;

u8 security_mode = 0;
u8 security_alarm = 0;
u8 ui_busy = 0;

u8 dht11_temp = 0;
u8 dht11_humi = 0;
u8 dht11_data_valid = 0;
u16 mq2_adc_value = 0;

char Uart2_Buf[BUF2_MAX];
char Uart3_Buf[BUF3_MAX];

static volatile u16 s_uart2_wr = 0;
static volatile u16 s_uart3_wr = 0;

static sensor_state_t g_sensor;
static esp_state_t g_esp;
extern volatile u32 g_net_reconnect_count;
extern volatile u32 g_net_offline_count;
extern volatile u16 g_cap_replay_count;
extern volatile u16 g_cap_sd_write_fail_count;
volatile unsigned char g_as608_user_abort = 0u;
static volatile u32 g_false_alarm_count = 0u;
static volatile u32 g_runtime_exception_count = 0u;

void AS608_PollYield(void)
{
    KeyboardSM_Tick();
}

void CLR_Buf2(void)
{
    memset(Uart2_Buf, 0, sizeof(Uart2_Buf));
    s_uart2_wr = 0;
}

void CLR_Buf(void)
{
    memset(Uart3_Buf, 0, sizeof(Uart3_Buf));
    s_uart3_wr = 0;
}

u8 Find2(char *a)
{
    if(a == NULL) return 0;
    return (strstr(Uart2_Buf, a) != NULL) ? 1u : 0u;
}

u8 Find(char *a)
{
    if(a == NULL) return 0;
    return (strstr(Uart3_Buf, a) != NULL) ? 1u : 0u;
}

void Security_Set_Mode(u8 armed)
{
    security_mode = armed ? 1u : 0u;
}

void ESP8266_CooperativeYield(void)
{
    KeyboardSM_Tick();
}

void USART3_IRQHandler(void)
{
    if(USART_GetITStatus(BOARD_USART3_INSTANCE, USART_IT_RXNE) != RESET)
    {
        char c = (char)USART_ReceiveData(BOARD_USART3_INSTANCE);

        if(s_uart2_wr < (u16)(BUF2_MAX - 1u))
        {
            Uart2_Buf[s_uart2_wr++] = c;
            Uart2_Buf[s_uart2_wr] = '\0';
        }
        if(s_uart3_wr < (u16)(BUF3_MAX - 1u))
        {
            Uart3_Buf[s_uart3_wr++] = c;
            Uart3_Buf[s_uart3_wr] = '\0';
        }
    }
}

static void app_init(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    delay_init();

    /* [M1.6] 先把 ESP8266 EN(PC9) 配成推挽输出并置高，给 ESP-01S 一个稳定的
     * "enable" 电平。必须在 USART2_Init_Config 之前完成，否则 ESP 还没真正
     * 启动 UART，后续所有 AT 命令都会超时；现象就是 ESP 模块灯闪一下即熄。
     * 详见 esp8266_tls.c:ESP8266_EN_GPIO_Init() 注释。*/
    ESP8266_EN_GPIO_Init();

    uart1_Init(57600);
    USART2_Init_Config(BOARD_WIFI_UART_BAUD);

    BEEP_AND_RELAY_GPIO_Init();
    Actuator_EnterSafeState();
    Key_Init();
    TIM2_Init(7199, 99);
    HC_SR501_Init();
    HC_SR501_EXTI_Init();
    DHT11_Init();
    MQ2_Init();

#if EN_OV7670_LOCAL
    OV7670_FIFO_Init();
    Capture_Task_Create();
#endif

    OLED_View_Init();
    OLED_View_ShowBootSelfTest();
    LockManager_Init();
    KeyboardSM_Init();
    Linkage_Init();
    SysLog_Init();
    SysLog_Add(LOG_EVT_CONFIG, "BOOT");
    if(WDG_LastResetWasIWDG())
    {
        SysLog_Add(LOG_EVT_ALARM, "RST_IWDG");
    }
    WDG_Init();
    WDG_HwInit();

    /* [M1.5] 自检页结束后先画一次"初始仪表盘"：
     * 目的：M3 未完成前，ESP8266_OneNET_InitFsm_Poll 首次进入 case 40 会
     *       同步阻塞 10~45s 做 CWJAP/MQTTCONN，期间主循环不能刷 OLED。
     *       若不做这次"预刷"，用户会看到自检页挂很久而误以为系统死机。
     *       g_sensor/g_esp 均为 BSS 零值，初显为 T:00 H:00 MQ:0 / NET:INIT /
     *       Input Password / DISARMED，与 M3 落地后一致，不引入过渡 UI。
     */
    OLED_View_RefreshDashboard(&g_sensor, LockManager_GetState(), &g_esp);
}

static void app_poll_sensors(void)
{
    static u32 s_dht_ms = 0;
    static u32 s_mq2_ms = 0;
    static u32 s_pir_quiet_until = 0u;
    static u8 s_dht_was_ok = 1u;
    static u8 s_dht_fail_streak = 0u;
    static u8 s_dht_ok_streak = 0u;
    static u32 s_dht_backoff_ms = APP_DHT_POLL_MS;
    static u8 s_mq2_was_alarm = 0u;
    static u16 s_mq2_last_adc = 0u;
    static u8 s_mq2_stuck_cnt = 0u;
    static u8 s_mq2_recover_cnt = 0u;
    static u8 s_mq2_fault = 0u;
    u32 now = Bare_GetTickMs();

    if((u32)(now - s_dht_ms) >= s_dht_backoff_ms)
    {
        u8 t = 0, h = 0;
        s_dht_ms = now;
        if(DHT11_Read_Data(&t, &h) == 0)
        {
            s_dht_fail_streak = 0u;
            if(s_dht_ok_streak < 0xFFu) s_dht_ok_streak++;
            dht11_temp = t;
            dht11_humi = h;
            dht11_data_valid = 1u;
            g_sensor.temp = t;
            g_sensor.humi = h;
            if(s_dht_ok_streak >= APP_DHT_RECOVER_SUCCESSES)
            {
                g_sensor.dht_ok = 1u;
                s_dht_backoff_ms = APP_DHT_POLL_MS;
            }
        }
        else
        {
            s_dht_ok_streak = 0u;
            if(s_dht_fail_streak < 0xFFu) s_dht_fail_streak++;
            dht11_data_valid = 0u;
            if(s_dht_fail_streak >= APP_DHT_OFFLINE_FAILS)
            {
                g_sensor.dht_ok = 0u;
                if(s_dht_was_ok)
                {
                    LOG_SENSOR("DHT offline");
                    SysLog_Add(LOG_EVT_ALARM, "DHT_OFFLINE");
                }
                if(s_dht_backoff_ms < APP_DHT_RETRY_BACKOFF_MAX_MS)
                {
                    s_dht_backoff_ms <<= 1;
                    if(s_dht_backoff_ms > APP_DHT_RETRY_BACKOFF_MAX_MS)
                        s_dht_backoff_ms = APP_DHT_RETRY_BACKOFF_MAX_MS;
                }
            }
        }
        if(g_sensor.dht_ok && !s_dht_was_ok)
        {
            LOG_SENSOR("DHT recover");
            SysLog_Add(LOG_EVT_CONFIG, "DHT_RECOVER");
        }
        s_dht_was_ok = g_sensor.dht_ok;
    }

    if((u32)(now - s_mq2_ms) >= (u32)APP_MQ2_POLL_MS)
    {
        s_mq2_ms = now;
        mq2_adc_value = MQ2_Read_ADC_Filter();
        g_sensor.mq2_adc = mq2_adc_value;
        if(mq2_adc_value > 4095u)
        {
            s_mq2_fault = 1u;
        }
        else
        {
            u16 diff = (mq2_adc_value > s_mq2_last_adc) ? (mq2_adc_value - s_mq2_last_adc) : (s_mq2_last_adc - mq2_adc_value);
            if(diff <= APP_MQ2_STUCK_DIFF_ADC)
            {
                if(s_mq2_stuck_cnt < 0xFFu) s_mq2_stuck_cnt++;
            }
            else
            {
                s_mq2_stuck_cnt = 0u;
                if(s_mq2_fault)
                {
                    if(s_mq2_recover_cnt < 0xFFu) s_mq2_recover_cnt++;
                    if(s_mq2_recover_cnt >= APP_MQ2_RECOVER_GOOD_COUNT)
                    {
                        s_mq2_fault = 0u;
                        s_mq2_recover_cnt = 0u;
                        SysLog_Add(LOG_EVT_CONFIG, "MQ2_RECOVER");
                        LOG_SENSOR("MQ2 recover");
                    }
                }
            }
            if(s_mq2_stuck_cnt >= APP_MQ2_STUCK_COUNT)
            {
                if(!s_mq2_fault)
                {
                    SysLog_Add(LOG_EVT_ALARM, "MQ2_FAULT");
                    LOG_SENSOR("MQ2 fault");
                }
                s_mq2_fault = 1u;
                s_mq2_recover_cnt = 0u;
            }
        }
        s_mq2_last_adc = mq2_adc_value;
        g_sensor.mq2_alarm = s_mq2_fault ? 0u : MQ2_Check_Alarm(mq2_adc_value);
        if(g_sensor.mq2_alarm && !s_mq2_was_alarm)
        {
#if BOARD_MQ2_ALARM_ENABLE
            Linkage_OnGasState(1u);
#if EN_OV7670_LOCAL
            Capture_Request(CAP_EVT_GAS);
#endif
#endif
            LOG_SENSOR("MQ2 alarm on");
        }
        if(!g_sensor.mq2_alarm && s_mq2_was_alarm)
        {
#if BOARD_MQ2_ALARM_ENABLE
            Linkage_OnGasState(0u);
#endif
            LOG_SENSOR("MQ2 alarm clear");
        }
        s_mq2_was_alarm = g_sensor.mq2_alarm;
    }

    if(HC_SR501_IRQHandler_GetFlag())
    {
        HC_SR501_IRQHandler_ClearFlag();
        if(!security_mode)
        {
            g_false_alarm_count++;
            SysLog_Add(LOG_EVT_CONFIG, "PIR_FALSE_ALARM");
            s_pir_quiet_until = now + (u32)APP_PIR_SUPPRESS_MS;
            LOG_SENSOR("PIR suppress");
        }
        if((s32)(now - s_pir_quiet_until) >= 0)
        {
            g_sensor.pir_alarm = 1u;
        }
        else
        {
            s_pir_quiet_until = now + (u32)APP_PIR_SUPPRESS_MS;
        }
    }
    else if(!HC_SR501_Poll_Triggered())
    {
        g_sensor.pir_alarm = 0u;
    }
}

static void app_report_stats(void)
{
    static u32 s_last_ms = 0u;
    u32 now = Bare_GetTickMs();
    if((u32)(now - s_last_ms) < (u32)APP_STAT_REPORT_MS) return;
    s_last_ms = now;
    LOG_STAT("false_alarm=%lu reconnect=%lu replay=%u sd_fail=%u run_ex=%lu",
             (unsigned long)g_false_alarm_count,
             (unsigned long)g_net_reconnect_count,
             (unsigned)g_cap_replay_count,
             (unsigned)g_cap_sd_write_fail_count,
             (unsigned long)g_runtime_exception_count);
}

static void app_export_stats(void)
{
    static u32 s_last_ms = 0u;
    char line[220];
    u32 now = Bare_GetTickMs();
    if((u32)(now - s_last_ms) < (u32)APP_STAT_EXPORT_MS) return;
    s_last_ms = now;

    /* 固定 JSON 字段名，便于第6章测试脚本稳定解析 */
    sprintf(line,
            "{\"tag\":\"STAT_EXPORT\",\"tick\":%lu,\"false_alarm\":%lu,\"reconnect\":%lu,\"replay\":%u,\"sd_fail\":%u,\"run_ex_72h\":%lu}",
            (unsigned long)now,
            (unsigned long)g_false_alarm_count,
            (unsigned long)g_net_reconnect_count,
            (unsigned)g_cap_replay_count,
            (unsigned)g_cap_sd_write_fail_count,
            (unsigned long)g_runtime_exception_count);
    uart1_SendStr(line);
    uart1_SendStr("\r\n");
}

static void app_poll_alarm_and_act(void)
{
    alarm_type_t alarm = ALARM_NONE;

    if(security_mode && g_sensor.pir_alarm) alarm = ALARM_PIR;
    if(BOARD_MQ2_ALARM_ENABLE && g_sensor.mq2_alarm)
        alarm = (alarm == ALARM_PIR) ? ALARM_BOTH : ALARM_GAS;

    security_alarm = (alarm != ALARM_NONE) ? 1u : 0u;

    if(alarm != ALARM_NONE)
    {
        BEEP_SoundOn();
        if(alarm == ALARM_PIR || alarm == ALARM_BOTH)
            Linkage_OnIntrusion();
        if(alarm == ALARM_GAS || alarm == ALARM_BOTH)
            Linkage_OnMQ2_Alarm();
#if EN_OV7670_LOCAL
        if(alarm == ALARM_PIR || alarm == ALARM_BOTH)
            Capture_Request(CAP_EVT_INTRUSION);
#endif
    }
    else
    {
        BEEP_SoundOff();
    }

    OLED_View_ShowAlarm(alarm);
}

static void app_poll_net(void)
{
    static u8 s_last_online = 0u;
    static u32 s_last_reconnect_cnt = 0u;
    static u32 s_last_offline_cnt = 0u;
#if EN_ESP8266_ONENET
    ESP8266_OneNET_InitFsm_Poll();
    g_esp.wifi_ready = tls_inited ? 1u : 0u;
    g_esp.hb_ok = ESP8266_Online_Flag ? 1u : 0u;
    if(ESP8266_Online_Flag && !s_last_online)
    {
        LOG_NET("online");
        SysLog_Add(LOG_EVT_CONFIG, "NET_RECOVER");
    }
    if(!ESP8266_Online_Flag && s_last_online)
    {
        LOG_NET("offline");
        SysLog_Add(LOG_EVT_ALARM, "NET_OFFLINE");
        g_runtime_exception_count++;
    }
    if(g_net_reconnect_count != s_last_reconnect_cnt)
    {
        char msg[48];
        sprintf(msg, "NET_RECONN_%lu", (unsigned long)g_net_reconnect_count);
        SysLog_Add(LOG_EVT_CONFIG, msg);
        s_last_reconnect_cnt = g_net_reconnect_count;
    }
    if(g_net_offline_count != s_last_offline_cnt)
    {
        char msg[48];
        sprintf(msg, "NET_OFF_%lu", (unsigned long)g_net_offline_count);
        SysLog_Add(LOG_EVT_ALARM, msg);
        s_last_offline_cnt = g_net_offline_count;
    }
    s_last_online = ESP8266_Online_Flag ? 1u : 0u;
    if(ESP8266_Online_Flag)
    {
        OneNET_Parse_Cmd();
        OneNET_Publish_Data(dht11_temp, dht11_humi, mq2_adc_value,
                            (RELAY == 0) ? 1u : 0u,
                            security_mode, security_alarm, Ctrl_Led);
        CLR_Buf2();
    }
#else
    g_esp.wifi_ready = 0u;
    g_esp.hb_ok = 0u;
    s_last_online = 0u;
#endif
}

/* [M1.9] 主循环单环节阻塞定位探针。
 * 在每个 *_Tick/*_Poll 调用之前，把一个标识字母写到 OLED 第 3 行最后一格
 * (x=120,y=48)。正常情况下 main loop 一圈走完，这个格子会被
 * OLED_View_RefreshDashboard 里第 3 行整行刷新覆盖回空格；
 * 如果 main loop 卡在某个环节，OLED 上会持久显示那一环节的字母：
 *   Z = while(1) 头部（上一次 delay_ms 刚出）
 *   K = KeyboardSM_Tick      前
 *   L = LockManager_Tick     前
 *   S = app_poll_sensors     前（DHT11 / MQ2 / PIR）
 *   A = app_poll_alarm_and_act 前
 *   N = app_poll_net         前（ESP8266 FSM）
 *   C = Bare_CapturePoll     前（OV7670 + SD）
 *   R = app_report_stats     前
 *   X = app_export_stats     前（UART1 写 JSON）
 *   O = OLED_View_RefreshDashboard 前
 * 用法：Rebuild+Download 后上电，静等 10~30s，看 OLED 第 3 行末尾停在哪个字母。
 * 一旦定位出具体环节，就可以针对性插更细的桩或去掉该环节先让联网跑起来。
 * 副作用：每圈多 10 次单字符 I2C 写（SSD1306 软件 I2C，每次 ~1ms），共 +10ms/圈。
 */
static void app_dbg_mark(char c)
{
    OLED_ShowChar(120, 48, c, 16);
}

int main(void)
{
    app_init();
    Security_Set_Mode(0);

#if USE_FREERTOS
    AppRTOS_Start();
    while(1) {}
#else
    while(1)
    {
        app_dbg_mark('Z');
        app_dbg_mark('K'); KeyboardSM_Tick();
        app_dbg_mark('L'); LockManager_Tick();
        app_dbg_mark('S'); app_poll_sensors();
        WDG_Mark(WDG_SRC_SENSOR);
        app_dbg_mark('A'); app_poll_alarm_and_act();
        WDG_Mark(WDG_SRC_ALARM);
        app_dbg_mark('N'); app_poll_net();
        WDG_Mark(WDG_SRC_NET);
        app_dbg_mark('C'); Bare_CapturePoll();
        app_dbg_mark('R'); app_report_stats();
        app_dbg_mark('X'); app_export_stats();
        app_dbg_mark('O'); OLED_View_RefreshDashboard(&g_sensor, LockManager_GetState(), &g_esp);
        WDG_Mark(WDG_SRC_UI);
        WDG_Mark(WDG_SRC_SYSMON);
        WDG_Pump();
        delay_ms(20);
    }
#endif
}